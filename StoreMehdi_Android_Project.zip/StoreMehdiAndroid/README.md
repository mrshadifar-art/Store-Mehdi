# Store Mehdi — Android APK project

این پروژه نسخه اندرویدی فایل HTML ویرایش‌شده است.

## نکته‌های اعمال‌شده
- ویرایشگر داخل اپ با چیدمان Desktop باز می‌شود.
- اپ در حالت Landscape اجرا می‌شود تا فضای بیشتری برای ویرایشگر داشته باشد.
- انتخاب فایل از حافظه گوشی برای ورودی‌های HTML فعال است.
- خروجی‌های TGS / JSON / SVG از طریق پل اندروید در پوشه Downloads ذخیره می‌شوند.
- فایل HTML اصلی داخل `app/src/main/assets/index.html` قرار دارد.

## Build ابری با GitHub Actions
Workflow نمونه در `.github/workflows/build-apk.yml` قرار گرفته است. با اجرای Workflow می‌توان APK را بدون کامپیوتر ساخت.
